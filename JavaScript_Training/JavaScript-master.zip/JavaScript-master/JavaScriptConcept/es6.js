/*
In es6 2 keywords are  added. 1 let 2.const
var keyword se jab varialble banate hai to wo global object ka property ban jata hai. window ka

*/
// var count = 1;
// var count;
// document.write(window.count)

let count = 1;
let count;
document.write(window.count1)
console.log(window.count1)