var digit1 = 5
alert(digit1)