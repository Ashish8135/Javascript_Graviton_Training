// How to select an element by id in JavaScript

// function btnclick(){
//     alert("Button was clicked");
// }
// second method
// let btn = document.getElementById('btn');
// // // btn.addEventListener('click',btnclick);

// // // through anonymous function
// btn.addEventListener('click',function(){
//     alert("Button is haveing clicked");
// });

// btn.addEventListener('mouseover',function(){
//     alert("Mouse over is activated");
// });

// btn.addEventListener('mouseout',function(){
//     alert("Mouse out is activated");
// });

